
function convertTemperature(){
    
    let scale  = prompt("Enter celsius or fahrenheit");       
        

    if(scale == "celsius"){
    
        let celsius = prompt("Enter Temperature");
        let result = (celsius - 32) * 5/9;


        document.getElementById("result").innerHTML = result;
    }else if(scale == "fahrenheit"){
        
        let fahrenheit = prompt("Enter Temperature");
        let result = (fahrenheit * 9/5) + 32;


        document.getElementById("result").innerHTML = result;
}
else{
    document.getElementById("result").innerHTML= "<p class='alert-error'>Invalid Value</p>";
}
}                              