// let number=10;

// while (number<=100){
//     console.log(number);
//     number=number+10;

// }

// let number2=10;
// do{

//     console.log(number2);
//     number2=number2+10;
// }while(number2<=100);


// for(let i=10; i<=100; i+=10){
//     console.log(i);
// }


// let myArray = ["George", "Andrew", "Fernanda", "Ricardo", "Tod"];

// for(let i=0;i<myArray.length;i++){
//     document.write(`
//         <p>${myArray[i]}</p>
//     `);
// }


// function fizzBuzz() {
//     for (let i = 0; i <= 100; i++){
//         if (i % 5 === 0 && i % 3 === 0) {
//             console.log('FizzBuzz');
//         }
//         else if (i % 3 === 0 ){
//         console.log('Fizz');
//         }
//         else if (i % 5 === 0 ){
//             console.log('Buzz');
    
//         }
//         else{
//             console.log(i);
//         }
//     }
// }

// fizzBuzz();



function multiply(number,msg){
    document.write(`----${msg} --- ${number}`);                
for( let i=1;i<10;i++){
document.write(`<p>${i} x ${number} = ${i*number}</p>`);
}
}
multiply(1,"multi");
multiply(2,"multi");
multiply(3,"multi");
multiply(4,"multi");