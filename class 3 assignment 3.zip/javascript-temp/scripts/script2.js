//functions
let counter = 0;

//1)creating the function
function increase(){
counter++;
    console.log(counter);
    document.getElementById("total").innerHTML = counter;
    if(counter==5){
        console.log("it's five");
    }
}

function decrease(){
    counter--;
    console.log(counter)
}
//2) call/run/execute the function


function sayHi(){
    let userName=prompt("Enter the number:");

    console.log("welcome..." + userName);
}

function multiByThree(){
    //1. get the number from a prompt
    let number = Number(prompt("Enter the number:"));
    //2. multi the number by 3
    let result =number*3;
    //3. display the result on the console
    document.getElementById("total").innerHTML=result;
}

// create that function that addin up two numbers (get them from the prompt)